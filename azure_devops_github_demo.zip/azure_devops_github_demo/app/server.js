
const express = require('express');
const app = express();
const port = process.env.PORT || 8080;
app.get('/', (req, res) => res.send('Hello from Azure DevOps Demo on GitHub Actions!'));
app.listen(port, () => console.log(`Listening on ${port}`));
